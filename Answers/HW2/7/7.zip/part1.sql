SELECT *
FROM movies
WHERE title LIKE '%Simin%';