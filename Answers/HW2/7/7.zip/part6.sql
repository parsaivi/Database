UPDATE users
SET Email = 'farzHMM@gmail.com'
WHERE first_name = 'hamid' AND last_name = 'farzane';
